rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page447706658-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page447706658" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page447706658-layer-text482851150" style="position: absolute; left: 570px; top: 40px; width: 167px; height: 48px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text482851150" data-review-reference-id="text482851150">\
            <div class="stencil-wrapper" style="width: 167px; height: 48px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:177px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12">\
                        <p><span class="bold underline" style="font-size: 42px;">ORIGEN</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-1266077985" style="position: absolute; left: 10px; top: 715px; width: 105px; height: 27px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1266077985" data-review-reference-id="1266077985">\
            <div class="stencil-wrapper" style="width: 105px; height: 27px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:115px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span class="bold" style="font-size: 24px;">N° Fojas:</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-2133709855" style="position: absolute; left: 125px; top: 710px; width: 30px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="2133709855" data-review-reference-id="2133709855">\
            <div class="stencil-wrapper" style="width: 30px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page447706658-layer-2133709855input" value="" style="width:28px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-d724e3340993847" style="position: absolute; left: 175px; top: 255px; width: 920px; height: 450px" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="d724e3340993847" data-review-reference-id="d724e3340993847">\
            <div class="stencil-wrapper" style="width: 920px; height: 450px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 450px; width:920px;" width="920" height="450" viewBox="0 0 920 450">\
                     <g width="920" height="450">\
                        <rect x="0" y="0" width="920" height="450" style="stroke-width:1;stroke:black;fill:white;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-1277344016" style="position: absolute; left: 305px; top: 310px; width: 61px; height: 27px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1277344016" data-review-reference-id="1277344016">\
            <div class="stencil-wrapper" style="width: 61px; height: 27px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:71px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span class="bold" style="font-size: 24px;">Para:</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-1171107075" style="position: absolute; left: 460px; top: 615px; width: 133px; height: 55px" data-stencil-type="default.iphoneButton" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="1171107075" data-review-reference-id="1171107075">\
            <div class="stencil-wrapper" style="width: 133px; height: 55px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" title="" style="height: 55px;width:133px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="133" height="55" viewBox="0 0 133 55"><a>\
                        <path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,54.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-45 0.5,-2 1,-1 1,-1 2,-0.5 123,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,45 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></path>\
                        <text x="66.5" y="27.5" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Enviar</text></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-267871458" style="position: absolute; left: 380px; top: 305px; width: 150px; height: 30px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="267871458" data-review-reference-id="267871458">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page447706658-layer-267871458select" style="width:150px;height:30px;" title="">\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-1207342090" style="position: absolute; left: 450px; top: 390px; width: 470px; height: 170px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1207342090" data-review-reference-id="1207342090">\
            <div class="stencil-wrapper" style="width: 470px; height: 170px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><textarea id="__containerId__-page447706658-layer-1207342090input" rows="" cols="" style="width:468px;height:166px;padding: 0px;border-width:1px;"></textarea></div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-1317212550" style="position: absolute; left: 720px; top: 305px; width: 78px; height: 27px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1317212550" data-review-reference-id="1317212550">\
            <div class="stencil-wrapper" style="width: 78px; height: 27px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:88px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span class="bold" style="font-size: 24px;">Cargo:</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-1322195416" style="position: absolute; left: 815px; top: 305px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1322195416" data-review-reference-id="1322195416">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page447706658-layer-1322195416input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-396923125" style="position: absolute; left: 305px; top: 380px; width: 138px; height: 27px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="396923125" data-review-reference-id="396923125">\
            <div class="stencil-wrapper" style="width: 138px; height: 27px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:148px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span class="bold" style="font-size: 24px;">Instruccion:</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-1425141479" style="position: absolute; left: 716px; top: 610px; width: 60px; height: 60px" data-stencil-type="fonticon.icon" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1425141479" data-review-reference-id="1425141479">\
            <div class="stencil-wrapper" style="width: 60px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" style="width:60px;height:60px;" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="60" height="60" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e139" preserveAspectRatio="xMidYMid meet">\
\
<path d="M114.842 783.296v-603.999q0-12.233 8.42-20.652t20.731-8.5h736.411q11.915 0 20.334 8.5t8.42 20.652v603.999q0 11.915-8.42 20.334t-20.334 8.5h-736.412q-12.312 0-20.731-8.5t-8.42-20.334zM181.008 712.839l200.565-132.414q11.915 4.607 31.612 12.709t64.895 29.786 72.68 38.921q22.797 14.535 21.844 0.318-1.033-16.521-27.482-52.585-30.819-42.020-58.939-58.304l-7.625-3.972q14.616-14.535 44.561-47.659t52.744-58.859l22.875-25.815 3.652-3.652t9.373-7.944 14.218-9.929 17.077-7.943 18.904-3.652q14.218 0 30.264 8.262t24.941 16.601l8.975 8.261 116.843 118.432v-317.012h-661.985v496.448zM240.979 348.723q0-29.786 21.127-51.073t51.312-21.368 51.312 21.368 21.208 51.073q0 30.184-21.208 51.312t-51.312 21.208-51.312-21.208-21.127-51.312z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e145" preserveAspectRatio="xMidYMid meet">\
\
<path d="M114.842 742.943v-493.509q0-13.502 9.77-23.273t23.353-9.77h44.005l11.597-34.792q4.607-12.868 17.315-22.161t26.372-9.295h165.457q13.583 0 26.292 9.295t17.396 22.161l11.597 34.792h308.751q13.583 0 23.353 9.77t9.77 23.273v99.289h-512.97q-22.241 0-32.487 22.875zM127.075 847.556l174.114-434.889q4.926-12.63 18.348-21.685t27.008-9.134h728.070q13.583 0 19.699 9.134t1.191 21.685l-174.114 434.889q-4.926 12.55-18.348 21.606t-27.008 9.135h-728.070q-13.583 0-19.699-9.135t-1.192-21.606z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e145-->\
                     <use xlink:href="#icon-glyph-e145"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-709134663" style="position: absolute; left: 625px; top: 610px; width: 68px; height: 68px" data-stencil-type="fonticon.icon" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="709134663" data-review-reference-id="709134663">\
            <div class="stencil-wrapper" style="width: 68px; height: 68px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" style="width:68px;height:68px;" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="68" height="68" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e139-->\
                     <use xlink:href="#icon-glyph-e139"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page447706658-layer-539755015" style="position: absolute; left: 190px; top: 255px; width: 112px; height: 27px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="539755015" data-review-reference-id="539755015">\
            <div class="stencil-wrapper" style="width: 112px; height: 27px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:122px;width:-webkit-max-content;width:-moz-max-content;width:max-content;"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span class="bold" style="font-size: 24px;">Rennviar:</span></p></span></span></div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page447706658"] .border-wrapper,\
         		body[data-current-page-id="page447706658"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page447706658"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page447706658"] .simulation-container {\
         			height:768px;\
         		}\
         		\
         		body[data-current-page-id="page447706658"] .svg-border-1366-768 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page447706658"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:768px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page447706658",\
      			"name": "Reenviar",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":768,\
      			"parentFolder": "",\
      			"frame": "desktop",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');